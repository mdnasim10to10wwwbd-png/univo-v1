# UNIVO V1
Supabase email/password authentication connected.
Publishable key is configured in index.html.
Do not add any Supabase secret/service_role key to this file.
